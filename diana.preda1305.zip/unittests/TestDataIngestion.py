import unittest
from app import DataIngestor
import pandas as pd
import numpy as np

class TestDataIngestion(unittest.TestCase):
    def setUp(self):
        # Create a copy of the .csv file for testing with the first 4 entries
        self.data_ingestor = DataIngestor("./test_data.csv")
        self.question = "Percent of adults aged 18 years and older who have obesity"
        self.state = "Ohio"
        
    def test_states_mean_calculation(self):
        # Get the mean of the data
        means = self.data_ingestor.states_mean_request(self.question)
        # Check if the mean is correct
        self.assertDictEqual(means, {'New Mexico': 27.7, 'Ohio': 29.4})

    def test_state_mean_calculation(self):
        # Get the mean of the data
        mean = self.data_ingestor.state_mean_request(self.question, self.state)
        # Check if the mean is correct
        self.assertDictEqual(mean, {'Ohio': 29.4})
    
    def test_best5_calculation(self):
        # Get the best 5 states
        best5 = self.data_ingestor.best5_request(self.question)
        # Check if the best 5 states are correct (2 states in this case)
        self.assertEqual(best5, {'Ohio': 29.4, 'New Mexico': 27.7})
    
    def test_worst5_calculation(self):
        # Get the worst 5 states
        worst5 = self.data_ingestor.worst5_request(self.question)
        # Check if the worst 5 states are correct (2 states in this case)
        self.assertEqual(worst5, {'New Mexico': 27.7, 'Ohio': 29.4})
    
    def test_global_mean_calculation(self):
        # Get the global mean
        global_mean = self.data_ingestor.global_mean_request(self.question)
        # Round the values to 2 decimal places
        global_mean = {key: round(value, 2) for key, value in global_mean.items()}
        # Check if the global mean is correct
        self.assertDictEqual(global_mean, {'global_mean': 28.55})
    
    def test_diff_from_mean_calculation(self):
        # Get the difference from the mean
        diff_from_mean = self.data_ingestor.diff_from_mean_request(self.question)
        # Round the values to 2 decimal places
        diff_from_mean = {key: round(value, 2) for key, value in diff_from_mean.items()}
        # Check if the difference from the mean is correct
        self.assertDictEqual(diff_from_mean, {'Ohio': -0.85, 'New Mexico': 0.85})
    
    def test_state_diff_from_mean_calculation(self):
        # Get the difference from the mean
        state_diff_from_mean = self.data_ingestor.state_diff_from_mean_request(self.question, self.state)
        # Round the values to 2 decimal places
        state_diff_from_mean = {key: round(value, 2) for key, value in state_diff_from_mean.items()}
        # Check if the difference from the mean is correct
        self.assertDictEqual(state_diff_from_mean, {'Ohio': -0.85})
    
    def test_mean_by_category_calculation(self):
        # Get the mean by category
        mean_by_category = self.data_ingestor.mean_by_category_request(self.question)
        # Check if the mean by category is correct
        self.assertDictEqual(mean_by_category, {"('Ohio', 'Income', '$75,000 or greater')": 29.4, "('New Mexico', 'Income', '$25,000 - $34,999')": 27.7})
    
    def test_state_mean_by_category_calculation(self):
        # Get the mean by category
        state_mean_by_category = self.data_ingestor.state_mean_by_category_request(self.question, self.state)
        # Check if the mean by category is correct
        self.assertDictEqual(state_mean_by_category, {"Ohio": {"('Income', '$75,000 or greater')": 29.4}})

if __name__ == '__main__':
    unittest.main()
